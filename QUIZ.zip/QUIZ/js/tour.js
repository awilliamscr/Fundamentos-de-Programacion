document.addEventListener('DOMContentLoaded', () => {
    const zones = document.querySelectorAll('.zone');
    const modal = document.getElementById('modal');
    const modalText = document.getElementById('modalText');
    const closeModal = document.getElementById('closeModal');

    
    zones.forEach(zone => {
        zone.addEventListener('click', () => {
            const zoneText = zone.getAttribute('data-text');  
            modalText.textContent = zoneText;  // Asignar el texto al modal
            
          
            const rect = zone.getBoundingClientRect();
            const zoneTop = rect.top + window.scrollY;
            const zoneLeft = rect.left + window.scrollX;
            
          
            modal.style.top = `${zoneTop}px`;  
            modal.style.left = `${zoneLeft}px`;  

            modal.classList.add('show');  
        });
    });


    closeModal.addEventListener('click', () => {
        modal.classList.remove('show'); 
    });

  
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');  
        }
    });
});

