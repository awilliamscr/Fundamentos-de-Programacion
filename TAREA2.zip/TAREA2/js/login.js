document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector(".login-form");
    const usuarioInput = document.getElementById("usuario");
    const contrasenaInput = document.getElementById("contrasena");
    
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const usuario = usuarioInput.value.trim();
        const contrasena = contrasenaInput.value.trim();

     
        if (usuario === "" || contrasena === "") {
            alert("Por favor, complete todos los campos requtidos.");
            return;
        }

        
        if (usuario === "cenfo" && contrasena === "123") {
            window.location.href = "landing.html"; 
        } else {
            alert("El usuario o contrasena son incorrectos.");
        }
    });
});