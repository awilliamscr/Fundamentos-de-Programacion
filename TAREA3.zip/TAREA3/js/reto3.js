function navigateToUrl() {
    const select = document.getElementById('urlSelect');
    const url = select.value;

    if (url) {
        window.open(url, '_blank');
    }
}


function redirectToLogin() {
    window.location.href = 'index.html';
}