document.addEventListener('DOMContentLoaded', function() {
    const radioButtons = document.querySelectorAll('input[name="color"]');
    const carImage = document.getElementById('car-image');

    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            carImage.src = this.value; 
        });
    });
});


function redirectToLogin() {
    window.location.href = 'index.html';
}