document.querySelectorAll('area').forEach(area => {
    area.addEventListener('click', function (event) {
        event.preventDefault();
        const description = this.getAttribute('data-description');
        const descriptionDiv = document.getElementById('description');
        
        descriptionDiv.textContent = description;
        descriptionDiv.style.display = 'block';
    });
});



function redirectToLogin() {
    window.location.href = 'index.html';
}