const countryData = {
    "COSTA RICA": {
        description: "Costa Rica es un país de América Central con una geografía accidentada, que incluye bosques tropicales y costas en el Caribe y el Pacífico. Aunque su capital, San José, es hogar de instituciones culturales, como el Museo del Oro Precolombino, Costa Rica es conocida por sus playas, sus volcanes y su biodiversidad.",
        image: "imagenes/costarica.png"
    },
    "HONDURAS": {
        description: "Honduras es un país de América Central con costas en el mar Caribe al norte y en el océano Pacífico al sur. En el bosque tropical cerca de Guatemala, el antiguo sitio ceremonial maya de Copán tiene jeroglíficos tallados en piedra y estelas, altos monumentos de piedra.",
        image: "imagenes/honduras.png"
    },
    "GUATEMALA": {
        description: "Guatemala, un país de América Central al sur de México, tiene volcanes, bosques tropicales y antiguos sitios mayas. La capital, Ciudad de Guatemala, cuenta con el imponente Palacio Nacional de la Cultura y el Museo Nacional de Arqueología y Etnología. Antigua Guatemala, al oeste de la capital, contiene edificios coloniales españoles preservados.",
        image: "imagenes/guatemala.png"
    },
    "NICARAGUA": {
        description: "Nicaragua es un país de América Central ubicado entre el océano Pacífico y el mar Caribe, conocido por su espectacular territorio con lagos, volcanes y playas. El extenso lago Managua y el icónico estratovolcán Momotombo se ubican al norte de la capital, Managua. Al sur está Granada, que se destaca por su arquitectura colonial española y un archipiélago de islotes navegables con abundantes especies de aves tropicales.",
        image: "imagenes/nicaragua.png"
    },
    "EL SALVADOR": {
        description: "El Salvador es una pequeña nación de América Central. Es conocida por sus playas en el océano Pacífico, los sitios de surf y el paisaje montañoso. Su Ruta de las Flores es un camino serpenteante que pasa por plantaciones de café, bosques tropicales con cascadas y ciudades como Juayúa, con sus festivales gastronómicos cada fin de semana, junto con Ataco, donde hay alegres murales.",
        image: "imagenes/elsalvador.png"
    }
};

    $('#seleccionpaises').change(function() {
        const selectedCountry = $(this).val();
        const countryInfo = countryData[selectedCountry];

        if (countryInfo) {
                Swal.fire({
                    title: selectedCountry,
                    text: countryInfo.description,
                    imageUrl: countryInfo.image,
                    imageWidth: 400,
                    imageHeight: 200,
                    imageAlt: selectedCountry,
                    confirmButtonText: 'Cerrar'
        });
    }
});


function redirectToLogin() {
    window.location.href = 'index.html';
}