document.getElementById('submitBtn').addEventListener('click', function() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    const selectedInterests = Array.from(document.querySelectorAll('input[name="interest"]:checked'))
                                    .map(interest => interest.value);
    
    let resultText = "Has seleccionado: ";

    if (selectedOption) {
        resultText += `\nOpción: ${selectedOption.value}`;
        showImage(selectedOption.value);
    } else {
        resultText += "\nNinguna opción seleccionada.";
        clearImage();
    }

    if (selectedInterests.length > 0) {
        resultText += `\nPreferencias: ${selectedInterests.join(', ')}`;
    } else {
        resultText += "\nNo has seleccionado ningún interés.";
    }

    document.getElementById('result').innerText = resultText;
});

function showImage(option) {
    const imageContainer = document.getElementById('imageContainer');
    imageContainer.innerHTML = ''; 

    let img = document.createElement('img');
    img.className = 'img-fluid'; 

    if (option === 'Sopa Negra') {
        img.src = 'imagenes/sopanegra.png'; 
    } else if (option === 'Sopa Azteca') {
        img.src = 'imagenes/sopa.png'; 
    }

    imageContainer.appendChild(img);
}

function clearImage() {
    const imageContainer = document.getElementById('imageContainer');
    imageContainer.innerHTML = ''; 
}


function redirectToLogin() {
    window.location.href = 'index.html';
}