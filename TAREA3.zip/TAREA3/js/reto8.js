let students = [];
document.getElementById('addStudentBtn').addEventListener('click', () => {
    const name = document.getElementById('studentName').value;
    const nota1 = parseFloat(document.getElementById('nota1').value);
    const nota2 = parseFloat(document.getElementById('nota2').value);
    const nota3 = parseFloat(document.getElementById('nota3').value);

    if (name && !isNaN(nota1) && !isNaN(nota2) && !isNaN(nota3)) {
        const student = {
            name: name,
            grades: [nota1, nota2, nota3]
        };
        students.push(student);
        updateStudentSelect();
        clearInputs();
    } else {
        alert("Por favor, completee todos los campos.");
    }
});

document.getElementById('calculateBtn').addEventListener('click', () => {
    const selectedStudentName = document.getElementById('studentSelect').value;
    const student = students.find(s => s.name === selectedStudentName);
    
    if (student) {
        const total = student.grades.reduce((acc, grade) => acc + grade, 0);
        document.getElementById('result').innerText = `Total de Calificaciones: ${total}`;
    } else {
        alert("Por favor, seleccione un estudiante.");
    }
});

function updateStudentSelect() {
    const studentSelect = document.getElementById('studentSelect');
    studentSelect.innerHTML = ''; 

    students.forEach(student => {
        const option = document.createElement('option');
        option.value = student.name;
        option.textContent = student.name;
        studentSelect.appendChild(option);
    });
}

function clearInputs() {
    document.getElementById('studentName').value = '';
    document.getElementById('nota1').value = '';
    document.getElementById('nota2').value = '';
    document.getElementById('nota3').value = '';
}


function redirectToLogin() {
    window.location.href = 'index.html';
}