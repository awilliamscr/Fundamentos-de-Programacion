$(document).ready(function() {
    const carImages = {
        version1: 'imagenes/kia2023.png',
        version2: 'imagenes/kia2024.png',
        version3: 'imagenes/kia2025.png'
    };

    $('#carVersion').change(function() {
        const selectedVersion = $(this).val();
        const imageUrl = carImages[selectedVersion];

        if (imageUrl) {
            $('#carImage').attr('src', imageUrl).show();
        } else {
            $('#carImage').hide();
        }
    });

    $('#calculateBtn').click(function() {
        const version = $('#carVersion').val();
        const year = $('#carYear').val();

        if (!version || !year) {
            $('#result').text('Por favor selecciona todas las opciones.');
            return;
        }

        let price = 20000;
        price += (version === 'version1' ? 1500 : version === 'version2' ? 2500 : 3500);
        price += (year === '2021' ? 0 : year === '2022' ? 3000 : 5000);

        $('#result').text(`Precio estimado: $${price}`);
    });
});


function redirectToLogin() {
    window.location.href = 'index.html';
}