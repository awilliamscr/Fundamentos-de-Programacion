document.getElementById('buscarBtn').addEventListener('click', function() {
    const cedula = document.getElementById('cedulaInput').value;
    const resultadoDiv = document.getElementById('resultado');

    const empleados = {
        "109110338": { nombre: "Juan", apellidos: "Perez", foto: "imagenes/juan.jpg", lugar: "Oficina Heredia" },
        "209110338": { nombre: "Ana", apellidos: "Gomez", foto: "imagenes/ana.jpg", lugar: "Sede Limon" },
        "309110338": { nombre: "Luis", apellidos: "Fernandez", foto: "imagenes/luis.jpg", lugar: "Sede Puntarenas" },
        "409110338": { nombre: "Marta", apellidos: "Diaz", foto: "imagenes/marta.jpg", lugar: "Oficina Alajuela" },
        "509110338": { nombre: "Carlos", apellidos: "Lopez", foto: "imagenes/carlos.jpg", lugar: "Sede Cartago" }
    };

    resultadoDiv.innerHTML = ""; 

    if (empleados[cedula]) {
        const empleado = empleados[cedula];
        resultadoDiv.innerHTML = `
            <h3>Información del Empleado:</h3>
            <img src="${empleado.foto}" alt="Foto de ${empleado.nombre}" class="img-fluid" />
            <p><strong>Nombre:</strong> ${empleado.nombre}</p>
            <p><strong>Apellidos:</strong> ${empleado.apellidos}</p>
            <p><strong>Lugar:</strong> ${empleado.lugar}</p>
        `;
    } else {
        resultadoDiv.innerHTML = "<div class='alert alert-warning'>El usuario NO existe.</div>";
    }

    resultadoDiv.style.display = 'block'; 
});


function redirectToLogin() {
    window.location.href = 'index.html';
}