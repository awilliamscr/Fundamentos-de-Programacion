document.getElementById('invoiceForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtener valores del formulario
    const clientName = document.getElementById('clientName').value;
    const item = document.getElementById('item').value;
    const quantity = parseFloat(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);

    // Calcular subtotal, IVA, servicio y total
    const subtotal = quantity * price;
    const iva = subtotal * 0.13;
    const service = subtotal * 0.05;
    const total = subtotal + iva + service;

    // Mostrar resultados
    document.getElementById('outputClientName').textContent = clientName;
    document.getElementById('outputItem').textContent = item;
    document.getElementById('outputQuantity').textContent = quantity;
    document.getElementById('outputPrice').textContent = price.toFixed(2);
    document.getElementById('outputSubtotal').textContent = subtotal.toFixed(2);
    document.getElementById('outputIVA').textContent = iva.toFixed(2);
    document.getElementById('outputService').textContent = service.toFixed(2);
    document.getElementById('outputTotal').textContent = total.toFixed(2);

    document.getElementById('invoiceOutput').style.display = 'block';
});

function redirectToLogin() {
    window.location.href = 'index.html';
}